
package bubblesort;

public class BubbleSort {
    
    public static void main(String[] args) { //Aqui é onde vai ficar o final com o antes e depois
        
        int[] vetor = {5, 2, 9, 1, 3, 8, 6, 4, 7, 10}; //informei o vetor como inteiro e com os respectivos números manualmente
        
        System.out.println("Vetor antes da ordenação:");
        exibirVetor(vetor);
        
        bubbleSort(vetor);
        
        System.out.println("Vetor após a ordenação:");
        exibirVetor(vetor);
        
    }
    
    public static void bubbleSort(int[] vetor) { //Aqui é onde ele ficará em loop até ser completamente organizado
        int n = vetor.length;
        
        for (int i = 0; i < n - 1; i++) { //aqui é percorrido o vetor inteiro e usamos o "i < n - 1" para que ele não precise verificar o último número que após a primeira interação ele já estará na posição correta.
            for (int j = 0; j < n - i - 1; j++) { //aqui no "j < n - i - 1" podemos ignorar o último elemento já ordenado e reduzir o tamanho do vetor.
                if (vetor[j] > vetor[j + 1]) {
                    int temp = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temp;
                }
            }
        }
    }
    
    public static void exibirVetor(int[] vetor) { //Aqui é onde ele terá a função de formatar o print final
        for (int i = 0; i < vetor.length; i++) {
            System.out.print(vetor[i] + " ");
        }
        
        System.out.println();
    }    
}

//PASSO A PASSO --------------
//Inicialmente, temos um vetor de elementos não ordenados.
//Exemplo: [5, 2, 9, 1, 3, 8, 6, 4, 7, 10]
//
//O algoritmo começa percorrendo o vetor a partir do primeiro elemento até o penúltimo elemento. Isso é feito com o primeiro loop for, controlado pela variável i.
//
//Dentro do primeiro loop for, temos outro loop for aninhado, controlado pela variável j, que percorre o vetor a partir do primeiro elemento até o elemento atual (n - i - 1).
//
//Em cada iteração do loop interno, comparamos o elemento atual vetor[j] com o próximo elemento vetor[j + 1]. Se vetor[j] for maior que vetor[j + 1], realizamos uma troca entre eles.
//
//A troca é feita para que o elemento maior seja deslocado para a posição posterior no vetor. Após a troca, o maior elemento da iteração atual "borbulhou" para a posição correta no final do vetor.
//
//Ao final de uma iteração completa do loop interno, o maior elemento estará na posição correta no final do vetor.
//
//O processo continua com o próximo elemento do loop externo. Em cada iteração, o elemento máximo restante é colocado na posição correta no final do vetor.
//
//Após as iterações completas dos loops for, o vetor estará ordenado em ordem crescente.
//
//O algoritmo Bubble Sort é considerado ineficiente para vetores grandes, pois faz um número elevado de comparações e trocas. No entanto, é simples de entender e implementar.
//
//No exemplo do vetor [5, 2, 9, 1, 3, 8, 6, 4, 7, 10], o passo a passo seria:
//
//Iteração 1:
//[2, 5, 9, 1, 3, 8, 6, 4, 7, 10] // Troca: 5 <-> 2
//[2, 5, 9, 1, 3, 8, 6, 4, 7, 10] // Troca: 9 <-> 1
//[2, 5, 1, 9, 3, 8, 6, 4, 7, 10] // Troca: 9 <-> 3
//[2, 5, 1, 3, 9, 8, 6, 4, 7, 10] // Troca: 9 <-> 8
//[2, 5, 1, 3, 8, 9, 6, 4, 7, 10] // Troca: 9 <-> 6
//[2, 5, 1, 3, 8, 6, 9, 4, 7, 10] // Troca: 9 <-> 4
//[2, 5, 1, 3, 8, 6, 4, 9, 7, 10] // Troca: 9 <-> 7
//[2, 5, 1, 3, 8, 6, 4, 7, 9, 10] // Troca: 10 <-> 9
//
//Iteração 2:
//[2, 5, 1, 3, 8, 6, 4, 7, 9, 10] // Troca: 5 <-> 1
//[2, 1, 5, 3, 8, 6, 4, 7, 9, 10] // Troca: 5 <-> 3
//[2, 1, 3, 5, 8, 6, 4, 7, 9, 10] // Troca: 8 <-> 3
//[2, 1, 3, 5, 3, 8, 6, 4, 7, 9, 10] // Troca: 8 <-> 6
//[2, 1, 3, 5, 3, 6, 8, 4, 7, 9, 10] // Troca: 8 <-> 4
//[2, 1, 3, 5, 3, 6, 4, 8, 7, 9, 10] // Troca: 8 <-> 7
//
//Iteração 3:
//[2, 1, 3, 5, 3, 6, 4, 7, 8, 9, 10] // Troca: 3 <-> 2
//[1, 2, 3, 5, 3, 6, 4, 7, 8, 9, 10] // Troca: 5 <-> 3
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Troca: 6 <-> 3
//
//Iteração 4:
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Nenhuma troca ocorre
//
//Iteração 5:
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Nenhuma troca ocorre
//
//Iteração 6:
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Nenhuma troca ocorre
//
//Iteração 7:
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Nenhuma troca ocorre
//
//Iteração 8:
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Nenhuma troca ocorre
//
//Iteração 9:
//[1, 2, 3, 3, 5, 6, 4, 7, 8, 9, 10] // Nenhuma troca ocorre
//
//Após as iterações completas, o vetor estará ordenado em ordem crescente:
//[1, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10]
//Espero que isso esclareça como o algoritmo Bubble Sort funciona passo a passo!

//SITE: https://blog.betrybe.com/tecnologia/bubble-sort-tudo-sobre/